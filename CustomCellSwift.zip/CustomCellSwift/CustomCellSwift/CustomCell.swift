//
//  CustomCell.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 11/4/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var firstStatusLabel: UILabel!
    @IBOutlet weak var secondStatusLabel: UILabel!
    @IBOutlet weak var myImageView: UIImageView!
    @IBOutlet weak var followButton: UIButton!
    @IBOutlet weak var followedButton: UIButton!

    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.followButton.isHidden = true
        self.followedButton.isHidden = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func populateCell(_ dataObject: Data, isFollowed: Bool, indexPath: IndexPath, parentView: Any) {
        
        // Loading Background Color
        self.backgroundColor = UIColor.white
        
        // Loading Images -----* Upload SDWebImage *-----
        //var imgURL = (dataObject.value(forKey: "dataURL") as! String)
        //self.myImageView.contentMode = .scaleAspectFit
        //self.myImageView.sd_setImage(with: imgURL, placeholderImage: UIImage(named: "no-image.png")!, options: SDWebImageRefreshCached)
        
        // Loading Status Labels
        self.firstStatusLabel.text = dataObject.dataStatus1
        self.secondStatusLabel.text = dataObject.dataStatus2
        self.firstStatusLabel.isHidden = true
        self.secondStatusLabel.isHidden = true
        
        if isFollowed {
            self.followedButton.tag = indexPath.row
            self.followedButton.addTarget(parentView, action: #selector(self.followedButton), for: .touchUpInside)
            self.followedButton.isHidden = false
            self.followButton.isHidden = true
            
            // Status Lables
            self.firstStatusLabel.isHidden = false
            self.secondStatusLabel.isHidden = false
        }
        else {
            self.followButton.tag = indexPath.row
            self.followButton.addTarget(parentView, action: #selector(self.followButton), for: .touchUpInside)
            self.followedButton.isHidden = true
            self.followButton.isHidden = false
            
            // Status Labels
            self.firstStatusLabel.isHidden = true
            self.secondStatusLabel.isHidden = true
        }
        
    }

}
