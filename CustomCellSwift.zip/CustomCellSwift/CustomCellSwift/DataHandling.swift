//
//  DataHandling.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 1/12/17.
//  Copyright © 2017 Dase Inc. All rights reserved.
//

import UIKit

class DataHandling: NSObject, NSCoding {
    
    var indexPath: IndexPath?
    var dataId: String?
    
    init(dataId: String, indexPath: IndexPath) {
        super.init()
        self.dataId = dataId
        self.indexPath = indexPath
    }
    
    required init(coder aDecoder: NSCoder) {
        
        if let dataId = aDecoder.decodeObject(forKey: "dataId") as? String {
            self.dataId = dataId
        }
        
        if let indexPath = aDecoder.decodeObject(forKey: "indexPath") as? IndexPath {
            self.indexPath = indexPath
        }
        
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(dataId, forKey: "dataId")
        aCoder.encode(indexPath, forKey: "indexPath")
    }
    
    func save(defaults box: String) -> Bool {
        
        let defaults = UserDefaults.standard
        let savedData = NSKeyedArchiver.archivedData(withRootObject: self)
        defaults.set(savedData, forKey: box)
        return defaults.synchronize()
        
    }
    
    convenience init?(defaults box: String) {
        
        let defaults = UserDefaults.standard
        if let data = defaults.object(forKey: box) as? Data,
            let obj = NSKeyedUnarchiver.unarchiveObject(with: data) as? DataHandling,
            let dataId = obj.dataId,
            let indexPath = obj.indexPath {
            self.init(dataId: dataId, indexPath: indexPath)
        } else {
            return nil
        }
        
    }
    
    class func allSavedOrdering(_ maxRows: Int) -> [Int: [DataHandling]] {
        
        var result: [Int: [DataHandling]] = [:]
        for section in 0...1 {
            var rows: [DataHandling] = []
            for row in 0..<maxRows {
                let indexPath = IndexPath(row: row, section: section)
                if let ordering = DataHandling(defaults: indexPath.defaultsKey) {
                    rows.append(ordering)
                }
                rows.sort(by: { $0.indexPath! < $1.indexPath! })
            }
            result[section] = rows
        }
        
        return result
        
    }
    
}
