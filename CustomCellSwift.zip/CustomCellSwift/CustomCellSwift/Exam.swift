//
//  Exam.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 11/4/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class Exam: NSObject {
    
    //Strings
    var examName: String?
    var examStatus1: String?
    var examStatus2: String?
    var examURL: String?
    var examID: String?
    // New
    var examType: String?
    var examDate: String?
    var examPop: String?
    
    override init() {
        
    }
    
    //Converting Strings into Objects
    init(examName eName: String,
         andExamStatus1 eStatus1: String,
         andExamStatus2 eStatus2: String,
         andExamURL eURL: String,
         andExamID eID: String,
         // New
        andExamType eType: String,
        andExamDate eDate: String,
        andExamPop ePop: String)
    {
        
        super.init()
        
        self.examName = eName
        self.examStatus1 = eStatus1
        self.examStatus2 = eStatus2
        self.examURL = eURL
        self.examID = eID
        //New
        self.examType = eType
        self.examDate = eDate
        self.examPop = ePop
        
    }
    
}
