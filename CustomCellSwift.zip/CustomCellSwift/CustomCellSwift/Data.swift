//
//  Data.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 11/4/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class Data: NSObject {
    
    //Strings
    var dataName = ""
    var dataID = ""
    var dataStatus1 = ""
    var dataStatus2 = ""
    var dataURL = ""
    
    //Converting Strings into Objects
    
    init(dataName dName: String,
         andDataStatus1 dStatus1: String,
         andDataStatus2 dStatus2: String,
         andDataURL dURL: String,
         andDataID dID: String)
    {
        
        super.init()
        
        dataName = dName
        dataStatus1 = dStatus1
        dataStatus2 = dStatus2
        dataURL = dURL
        dataID = dID
        
    }

}
