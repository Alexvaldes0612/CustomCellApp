//
//  DataOrdering.swift
//  
//
//  Created by Alexander Valdes on 1/12/17.
//
//

import UIKit

class DataOrdering: NSObject, NSCoding {
    
    var indexPath: IndexPath?
    var dataId: String?
    
    init(dataId: String, indexPath: IndexPath) {
        super.init()
        self.dataId = dataId
        self.indexPath = indexPath
    }
    
    required init(coder aDecoder: NSCoder) {
        
        if let dataId = aDecoder.decodeObject(forKey: "dataId") as? String {
            self.dataId = dataId
        }
        
        if let indexPath = aDecoder.decodeObject(forKey: "indexPath") as? IndexPath {
            self.indexPath = indexPath
        }
        
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(dataId, forKey: "dataId")
        aCoder.encode(indexPath, forKey: "indexPath")
    }
    
    func save(defaults key: String) -> Bool {
        
        let defaults = UserDefaults.standard
        let savedData = NSKeyedArchiver.archivedData(withRootObject: self)
        defaults.set(savedData, forKey: key)
        return defaults.synchronize()
        
    }
    
    convenience init?(defaults key: String) {
        
        let defaults = UserDefaults.standard
        if let data = defaults.object(forKey: key) as? Data,
            let obj = NSKeyedUnarchiver.unarchiveObject(with: data) as? DataOrdering,
            let dataId = obj.dataId,
            let indexPath = obj.indexPath {
            self.init(dataId: dataId, indexPath: indexPath)
        } else {
            return nil
        }
        
    }
    
    class func allSavedOrdering(_ maxRows: Int) -> [Int: [DataOrdering]] {
        
        var result: [Int: [DataOrdering]] = [:]
        for section in 0...1 {
            var rows: [DataOrdering] = []
            for row in 0..<maxRows {
                let indexPath = IndexPath(row: row, section: section)
                if let ordering = DataOrdering(defaults: indexPath.defaultsKey) {
                    rows.append(ordering)
                }
                rows.sort(by: { $0.indexPath! < $1.indexPath! })
            }
            result[section] = rows
        }
        
        return result
        
    }
    
}
