//
//  Data.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 11/4/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class Game: NSObject {
    
    //Strings
    var gameName: String?
    var gameID: String?
    var gameStatus1: String?
    var gameStatus2: String?
    var gameURL: String?
    
    override init() {
        
    }
    
    //Converting Strings into Objects
    init(gameName gName: String,
         andGameStatus1 gStatus1: String,
         andGameStatus2 gStatus2: String,
         andGameURL gURL: String,
         andGameID gID: String)
    {
        
        super.init()
        
        self.gameName = gName
        self.gameStatus1 = gStatus1
        self.gameStatus2 = gStatus2
        self.gameURL = gURL
        self.gameID = gID
        
    }

}
