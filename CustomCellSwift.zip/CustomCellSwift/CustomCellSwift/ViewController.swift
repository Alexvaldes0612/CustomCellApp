//
//  ViewController.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 10/31/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

// Server URL (For Testing)
let getDataURL = "http://79.170.40.227/gamenotify.org/json.php"

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, URLSessionDataDelegate {
    
    // Outlets and Variables
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var mySearchBar: UISearchBar!
    
    var followedArray: NSMutableArray = []
    var dataArray: NSMutableArray = []
    
    var jsonArray: NSMutableArray = []
    var filteredArray: NSArray = []
    
    var isFiltered: Bool!
    
    // Startup
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Custom Cell
        self.myTableView.dataSource = self
        self.myTableView.delegate = self
        
        // Allocating Array
        followedArray = NSMutableArray()
        
        // Search Bar
        //mySearchBar.delegate = self
        
        // Dismissing Keyboard // for - let
        let gestureRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.hideKeyboard))
        myTableView.addGestureRecognizer(gestureRecognizer)
        
        // Load Data
        self.retrieveData()

    }

    // Memory Warning
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // Title for Header
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Followed Data"
        }
        else {
            return "All Data"
        }

    }
    
    // Height For Row
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 140
    }
    
    // Number of Rows in Section
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if !isFiltered {
            if section == 0 {
                return followedArray.count
            }
            else if section == 1 {
                return dataArray.count
            }
        }
        return filteredArray.count

    }
    
    // Number of Sections
    public func numberOfSections(in tableView: UITableView) -> Int {
        
        return 2
    }
    
    // CellForRowAt indexPath *Main*
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let CellIdentifier = "Cell"
        var cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier)!
        
        if cell != cell {
            cell = CustomCell(style: UITableViewCellStyle.default, reuseIdentifier: CellIdentifier)
        }
                
        // Coloring TableView
        myTableView.backgroundColor = UIColor.white
        
        // Configuring the cell
        var dataObject: Data
        
        if !isFiltered {
            if indexPath.section == 0 {
                dataObject = followedArray[indexPath.row] as! Data
                cell.populateCell(dataObject, isFollowed: true, indexPath: indexPath, parentView: self)
            }
            else if indexPath.section == 1 {
                dataObject = dataArray[indexPath.row] as! Data
                cell.populateCell(dataObject, isFollowed: false, indexPath: indexPath, parentView: self)
            }
        }
        else {
            dataObject = filteredArray[indexPath.row] as! Data
            cell.populateCell(dataObject, isFollowed: false, indexPath: indexPath, parentView: self)
        }
        return cell
    }
    
    
    // Follow Button
    @IBAction func followButtonClick(_ sender: Any) {
        
        // Adding row to tag
        var buttonPosition = (sender as AnyObject).convertPoint(CGPoint.zero, to: self.myTableView)
        var indexPath = self.myTableView.indexPathForRow(at: buttonPosition)!
        
        // Creating an action per tag
        if indexPath != nil {
            
            //NSLog(@"Current Row = %@", indexPath);
            
            // Showing Status Labels
            var cell = self.myTableView.cellForRow(atIndexPath: indexPath)!
            cell.firstStatusLabel.isHidden = false
            cell.secondStatusLabel.isHidden = false
            
            // Change Follow to Following
            (sender as AnyObject).setImage(UIImage(named: "follow.png")!, for: .normal)
            cell.followButton.isHidden = true
            cell.followedButton.isHidden = false
            self.myTableView.beginUpdates()
            
            // ----- Inserting Cell to Section 0 -----
            followedArray.insert(dataArray[indexPath.row], at: 0)
            myTableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
            //NSLog(@"indexPath.row = %ld", (long)indexPath.row);
            
            // ----- Removing Cell from Section 1 -----
            dataArray.remove(at: indexPath.row)
            var rowToRemove = indexPath.row
            self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 1)], with: true)
            //NSLog(@"Array =%@",followedArray);
            
            self.myTableView.endUpdates()
            
        }
    }
    
    // Unfollow Button
    @IBAction func followedButtonClick(_ sender: Any) {
        
        // Adding row to tag
        var buttonPosition = (sender as AnyObject).convertPoint(CGPoint.zero, to: self.myTableView)
        var indexPath = self.myTableView.indexPathForRow(at: buttonPosition)!
        
        // Creating an action per tag
        if indexPath != nil {
            
            //NSLog(@"Current Row = %@", indexPath);
            
            // Hiding Status Labels
            var cell = self.myTableView.cellForRow(atIndexPath: indexPath)!
            cell.firstStatusLabel.isHidden = true
            cell.secondStatusLabel.isHidden = true
            // Change Following to Follow
            (sender as AnyObject).setImage(UIImage(named: "followed.png")!, for: .normal)
            cell.followButton.isHidden = false
            cell.followedButton.isHidden = true
            
            self.myTableView.beginUpdates()
            
            // ----- Inserting Cell to Section 1 -----
            dataArray.insert(followedArray[indexPath.row], at: 0)
            myTableView.insertRows(at: [IndexPath(row: 0, section: 1)], with: .fade)
            //NSLog(@"indexPath.row = %ld", (long)indexPath.row);
            
            // ----- Removing Cell from Section 0 -----
            followedArray.remove(at: indexPath.row)
            var rowToRemove = indexPath.row
            self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 0)], with: true)
            //NSLog(@"Array =%@",followedArray);
            
            self.myTableView.endUpdates()
            
        }
    }
    
    // Settings Button *MISSING*
    @IBAction func settingsButton(_ sender: Any) {
        
    }
    
    // SEARCH BAR
    //
    
    
    // Hide Keyboard
    func hideKeyboard() {
        
        self.view.endEditing(false)
    }
    
    // Retrieving Data from Server
    func retrieveData() {
        
        let url: NSURL = NSURL(string: getDataURL)!
        let data: NSData = NSData(contentsOfURL: url)
        jsonArray = JSONSerialization.JSONObjectWithData(data, options: nil, error: nil)
        
        // Setting up data array
        //dataArray = NSMutableArray()
        var dataArray = []
        
        // Looping through jsonArray
        for i in 0..<jsonArray.count {
            // Create Data Object
            let dID: String = jsonArray[i].objectForKey("id") as! String!
            let dName: String = jsonArray[i].objectForKey("dataName") as! String!
            let dStatus1: String = jsonArray[i].objectForKey("dataStatus1") as! String!
            let dStatus2: String = jsonArray[i].objectForKey("dataStatus2") as! String!
            let dURL: String = jsonArray[i].objectForKey("dataURL") as! NSURL
            
            // Add Data Objects to Data Array
            dataArray.append(Data(dataName: dName, andDataStatus1: dStatus1, andDataStatus2: dStatus2, andDataURL: dURL, andDataID: dID))
        }
        
        self.myTableView.reloadData()
    }

}

