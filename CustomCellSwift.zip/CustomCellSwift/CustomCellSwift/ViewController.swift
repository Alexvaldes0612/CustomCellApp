//
//  ViewController.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 10/31/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, URLSessionDataDelegate {
    
    // Outlets and Variables
    @IBOutlet weak var myTableView: UITableView!
    @IBOutlet weak var mySearchBar: UISearchBar!
    
    var followedArray: NSMutableArray = []
    var gameArray: NSMutableArray = []
    
    var jsonArray: NSMutableArray = []
    var filteredArray: NSArray = []
    
    var isFiltered: Bool!
    
    // Startup
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Custom Cell
        self.myTableView.dataSource = self
        self.myTableView.delegate = self
        
        // Allocating Array
        followedArray = NSMutableArray()
        
        // Search Bar
        //self.mySearchBar.delegate = self
        
        // Dismissing Keyboard
        let gestureRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.hideKeyboard))
        myTableView.addGestureRecognizer(gestureRecognizer)
        
        // Load Data
        self.retrieveData()

    }

    // Memory Warning
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // Title for Header
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            return "Followed Games"
        }
        else {
            return "All Games"
        }
        
    }
 
    // Height For Row
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 140
    }
    
    // Number of Rows in Section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isFiltered != nil && isFiltered! { //Check isFiltered == false
            if section == 0 {
                return followedArray.count
            }
            else if section == 1 {
                return gameArray.count
            }
        }
        return filteredArray.count
        
    }
    
    // Number of Sections
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 2
    }
    
    // CellForRowAt indexPath
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let CellIdentifier = "Cell"
        var cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier) as! CustomCell
        
        if cell != cell {
            cell = CustomCell(style: UITableViewCellStyle.default, reuseIdentifier: CellIdentifier)
        }
                
        // Coloring TableView
        myTableView.backgroundColor = UIColor.white
        
        // Configuring the cell
        var gameObject: Game
        
        if isFiltered != nil && isFiltered! { //Check isFiltered == false
            if indexPath.section == 0 {
                gameObject = followedArray[indexPath.row] as! Game
                cell.populateCell(gameObject, isFollowed: true, indexPath: indexPath, parentView: self)
            }
            else if indexPath.section == 1 {
                gameObject = gameArray[indexPath.row] as! Game
                cell.populateCell(gameObject, isFollowed: false, indexPath: indexPath, parentView: self)
            }
        }
        else {
            gameObject = filteredArray[indexPath.row] as! Game
            cell.populateCell(gameObject, isFollowed: false, indexPath: indexPath, parentView: self)
        }
 
        return cell
    }
    
    
    // Follow Button
    @IBAction func followButtonClick(_ sender: Any) {
        
        // Adding row to tag
        let buttonPosition = (sender as AnyObject).convert(CGPoint.zero, to: self.myTableView)
        if let indexPath = self.myTableView.indexPathForRow(at: buttonPosition) {
            
            // Showing Status Labels
            let cell = self.myTableView.cellForRow(at: indexPath) as! CustomCell
            cell.firstStatusLabel.isHidden = false
            cell.secondStatusLabel.isHidden = false
            
            // Change Follow to Following
            (sender as AnyObject).setImage(UIImage(named: "follow.png")!, for: .normal)
            cell.followButton.isHidden = true
            cell.followedButton.isHidden = false
            self.myTableView.beginUpdates()
            
            // ----- Inserting Cell to Section 0 -----
            followedArray.insert(gameArray[indexPath.row], at: 0)
            myTableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
            
            // ----- Removing Cell from Section 1 -----
            gameArray.remove(at: indexPath.row)
            let rowToRemove = indexPath.row
            self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 1)], with: .automatic)
            
            self.myTableView.endUpdates()
            
        }
 
    }
    
    // Unfollow Button
    @IBAction func followedButtonClick(_ sender: Any) {
        
        // Adding row to tag
        let buttonPosition = (sender as AnyObject).convert(CGPoint.zero, to: self.myTableView)
        if let indexPath = self.myTableView.indexPathForRow(at: buttonPosition) {
            
            // Hiding Status Labels
            let cell = self.myTableView.cellForRow(at: indexPath) as! CustomCell
            cell.firstStatusLabel.isHidden = true
            cell.secondStatusLabel.isHidden = true
            
            // Change Following to Follow
            (sender as AnyObject).setImage(UIImage(named: "followed.png")!, for: .normal)
            cell.followButton.isHidden = false
            cell.followedButton.isHidden = true
            
            self.myTableView.beginUpdates()
            
            // ----- Inserting Cell to Section 1 -----
            gameArray.insert(followedArray[indexPath.row], at: 0)
            myTableView.insertRows(at: [IndexPath(row: 0, section: 1)], with: .fade)
            
            // ----- Removing Cell from Section 0 -----
            followedArray.remove(at: indexPath.row)
            let rowToRemove = indexPath.row
            self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 0)], with: .automatic)
            
            self.myTableView.endUpdates()
            
        }
 
    }
    
    // Settings Button
    @IBAction func settingsButton(_ sender: Any) {}
    
    // SEARCH BAR
    
    
    
    
    // Hide Keyboard
    func hideKeyboard() {
        
        self.view.endEditing(false)
    }
    
    // Retrieving Data from Server
    func retrieveData() {
        
        let getDataURL = "http://79.170.40.227/gamenotify.org/json.php"
        let url: NSURL = NSURL(string: getDataURL)!
        
        do {
            
            let data: Data = try Data(contentsOf: url as URL)
            jsonArray = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSMutableArray
            
            // Setting up dataArray
            let gameArray: NSMutableArray = []
            
            // Looping through jsonArray
            for i in 0..<jsonArray.count {
                
                // Create Data Object
                let gID: String = (jsonArray[i] as AnyObject).object(forKey: "id") as! String
                let gName: String = (jsonArray[i] as AnyObject).object(forKey: "gameName") as! String
                let gStatus1: String = (jsonArray[i] as AnyObject).object(forKey: "gameStatus1") as! String
                let gStatus2: String = (jsonArray[i] as AnyObject).object(forKey: "gameStatus2") as! String
                let gURL: String = (jsonArray[i] as AnyObject).object(forKey: "gameURL") as! String
                
                // Add Data Objects to Data Array
                gameArray.add(Game(gameName: gName, andGameStatus1: gStatus1, andGameStatus2: gStatus2, andGameURL: gURL, andGameID: gID))
                
                print(gameArray, gName, gStatus1, gStatus2)
                
            }
            
        }
        catch {
            print("Error: (Retrieving Data)")
        }
        
        myTableView.reloadData()
    }
    
}

