//
//  ViewController.swift
//  CustomCellSwift
//
//  Created by Alexander Valdes on 10/31/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, URLSessionDataDelegate, UISearchResultsUpdating, UISearchBarDelegate {
    
    // Outlets and Variables
    @IBOutlet weak var myTableView: UITableView!
    
    let searchController = UISearchController(searchResultsController: nil)
    
    var jsonArray: NSMutableArray = []
    var examArray = [Exam]()
    var followedArray = [Exam]()
    var filteredArray = [Exam]()
    
    // Startup
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Custom Cell
        self.myTableView.dataSource = self
        self.myTableView.delegate = self
        
        // Search Bar
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        myTableView.tableHeaderView = searchController.searchBar
        //
        searchController.searchBar.backgroundColor = UIColor.white
        searchController.searchBar.barTintColor = UIColor.white
        
        // Scope Bar
        searchController.searchBar.scopeButtonTitles = ["All", "Released", "Unreleased", "Open Exam"]
        searchController.searchBar.delegate = self
        
        // Dismissing Keyboard
        let gestureRecognizer: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.hideKeyboard))
        myTableView.addGestureRecognizer(gestureRecognizer)
        
        // Load Data
        self.retrieveData()
        
        // Sorting Array (Popular Order)
        examArray.sort { $0.examPop! > $1.examPop! }
            // (Also sort followedArray or allow user to reorder)
        

    }

    // Memory Warning
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // Title for Header
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if !(searchController.isActive && searchController.searchBar.text != "") {
            
            if section == 0 {
                return "Followed Exams"
            }
            else {
                return "All Exams"
            }
        }
        
        return "Filtered Exams"
    }
 
    // Height For Row
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 140
    }
    
    // Number of Rows in Section
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if !(searchController.isActive && searchController.searchBar.text != "") {
            
            if section == 0 {
                
                return followedArray.count
            }
            else if (section == 1) {
                
                return examArray.count
            }
        }
        
        return filteredArray.count
    }
    
    // Number of Sections
    func numberOfSections(in tableView: UITableView) -> Int {
        
        if !(searchController.isActive && searchController.searchBar.text != "") {
            
            return 2
        }
        
        return 1
    }
    
    // CellForRowAt indexPath
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let CellIdentifier = "Cell"
        var cell = tableView.dequeueReusableCell(withIdentifier: CellIdentifier) as! CustomCell
        
        if cell != cell {
            cell = CustomCell(style: UITableViewCellStyle.default, reuseIdentifier: CellIdentifier)
        }
                
        // Coloring TableView
        myTableView.backgroundColor = UIColor.white
        
        // Configuring the cell
        var examObject: Exam
        
        if !(searchController.isActive && searchController.searchBar.text != "") {
            if indexPath.section == 0 {
                examObject = followedArray[indexPath.row]
                cell.populateCell(examObject, isFollowed: true, indexPath: indexPath, parentView: self)
            }
            else if indexPath.section == 1 {
                examObject = examArray[indexPath.row]
                cell.populateCell(examObject, isFollowed: false, indexPath: indexPath, parentView: self)
            }
        }
        else {
            examObject = filteredArray[indexPath.row]
            cell.populateCell(examObject, isFollowed: false, indexPath: indexPath, parentView: self)
        }
 
        return cell
    }
    
    // Follow Button
    @IBAction func followButtonClick(_ sender: UIButton!) {
        
        // Adding row to tag
        let buttonPosition = (sender as AnyObject).convert(CGPoint.zero, to: self.myTableView)
        if let indexPath = self.myTableView.indexPathForRow(at: buttonPosition) {
            
            // Showing Status Labels
            let cell = self.myTableView.cellForRow(at: indexPath) as! CustomCell
            cell.firstStatusLabel.isHidden = false
            cell.secondStatusLabel.isHidden = false
            
            // Change Follow to Following
            (sender as UIButton).setImage(UIImage(named: "follow.png")!, for: .normal)
            cell.followButton.isHidden = true
            cell.followedButton.isHidden = false
            
            // Sending Data to Server: Adding +1
            sendData()
            
            // Checking wether to import from examArray or filteredArray to followedArray
            if !(searchController.isActive && searchController.searchBar.text != "") {
            
                self.myTableView.beginUpdates()
            
                // ----- Inserting Cell to followedArray -----
                followedArray.insert(examArray[indexPath.row], at: 0)
                myTableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
            
                // ----- Removing Cell from examArray -----
                examArray.remove(at: indexPath.row)
                let rowToRemove = indexPath.row
                self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 1)], with: .fade)
            
                self.myTableView.endUpdates()
            
            }
            else {
                
                self.myTableView.beginUpdates()
                
                // ----- Inserting Cell to followedArray -----
                followedArray.insert(filteredArray[indexPath.row], at: 0)
                myTableView.insertRows(at: [IndexPath(row: 0, section: 0)], with: .fade)
                
                // ----- Removing Cell from filteredArray -----
                filteredArray.remove(at: indexPath.row)
                let rowToRemove = indexPath.row
                self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 0)], with: .fade)
                
                self.myTableView.endUpdates()
                
            }
        }
    }
    
    // Unfollow Button
    @IBAction func followedButtonClick(_ sender: UIButton!) {
        
        // Adding row to tag
        let buttonPosition = (sender as AnyObject).convert(CGPoint.zero, to: self.myTableView)
        if let indexPath = self.myTableView.indexPathForRow(at: buttonPosition) {
            
            // Hiding Status Labels
            let cell = self.myTableView.cellForRow(at: indexPath) as! CustomCell
            cell.firstStatusLabel.isHidden = true
            cell.secondStatusLabel.isHidden = true
            
            // Change Following to Follow
            (sender as UIButton).setImage(UIImage(named: "followed.png")!, for: .normal)
            cell.followButton.isHidden = false
            cell.followedButton.isHidden = true
            
            self.myTableView.beginUpdates()
            
            // ----- Inserting Cell to Section 1 -----
            examArray.insert(followedArray[indexPath.row], at: 0)
            myTableView.insertRows(at: [IndexPath(row: 0, section: 1)], with: .fade)
            
            // ----- Removing Cell from Section 0 -----
            followedArray.remove(at: indexPath.row)
            let rowToRemove = indexPath.row
            self.myTableView.deleteRows(at: [IndexPath(row: rowToRemove, section: 0)], with: .fade)
            
            self.myTableView.endUpdates()
            
        }
    }
    
    // Settings Button
    @IBAction func settingsButton(_ sender: Any) {}
    
    // Sorting: Basic Button
    @IBAction func basicButton(_ sender: Any) {
        
        myTableView.reloadData()
    }
    
    // Sorting: ABC Button
    @IBAction func abcButton(_ sender: Any) {
        
        examArray.sort { $0.examName! < $1.examName! }
        
        myTableView.reloadData()
    }
    
    // Sorting: Date Button
    @IBAction func dateButton(_ sender: Any) {
    }
    
    // Sorting: Popular Button
    @IBAction func popularButton(_ sender: Any) {
    }
    
    // SEARCH BAR: Filtering Content
    func filterContentForSearchText(searchText: String, scope: String = "All") {
        
        filteredArray = examArray.filter { Exam in
            
            let categoryMatch = (scope == "All") || (Exam.examType == scope)
                        
            return categoryMatch && (Exam.examName?.lowercased().contains(searchText.lowercased()))!
        }
        myTableView.reloadData()
    }
    
    // SEARCH BAR: Updating Results
    func updateSearchResults(for searchController: UISearchController) {
        
        filterContentForSearchText(searchText: searchController.searchBar.text!)
    }
    
    // SEARCH BAR: Scope
    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
        
        filterContentForSearchText(searchText: searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
    }
    
    // SEARCH BAR: Updating Scope
    func updateSearchResultsForSearchController(searchController: UISearchController) {
        
        let searchBar = searchController.searchBar
        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
        filterContentForSearchText(searchText: searchController.searchBar.text!, scope: scope)
    }
    
    
    // Hide Keyboard
    func hideKeyboard() {
        
        self.view.endEditing(false)
    }
    
    // Retrieving Data from Server
    func retrieveData() {
        
        let getDataURL = "http://79.170.40.246/examnotify.org/get.php"
        let url: NSURL = NSURL(string: getDataURL)!
        
        do {
            
            let data: Data = try Data(contentsOf: url as URL)
            jsonArray = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSMutableArray
            
            // Looping through jsonArray
            for i in 0..<jsonArray.count {
                
                // Create Exam Object
                let eID: String = (jsonArray[i] as AnyObject).object(forKey: "id") as! String
                let eName: String = (jsonArray[i] as AnyObject).object(forKey: "examName") as! String
                let eStatus1: String = (jsonArray[i] as AnyObject).object(forKey: "examStatus1") as! String
                let eStatus2: String = (jsonArray[i] as AnyObject).object(forKey: "examStatus2") as! String
                let eURL: String = (jsonArray[i] as AnyObject).object(forKey: "examURL") as! String
                // New
                let eType: String = (jsonArray[i] as AnyObject).object(forKey: "examType") as! String
                let eDate: String = (jsonArray[i] as AnyObject).object(forKey: "examDate") as! String
                let ePop: String = (jsonArray[i] as AnyObject).object(forKey: "examPop") as! String
                
                // Add Exam Objects to Exam Array
                examArray.append(Exam(examName: eName, andExamStatus1: eStatus1, andExamStatus2: eStatus2, andExamURL: eURL, andExamID: eID, andExamType: eType, andExamDate: eDate, andExamPop: ePop))
                
            }
        }
        catch {
            print("Error: (Retrieving Data)")
        }
        
        myTableView.reloadData()
    }
    
    // Sending Data to Server
    func sendData() {
        
        let postDataURL = "http://79.170.40.246/examnotify.org/send.php"
        let url: NSURL = NSURL(string: postDataURL)!
        let request: NSMutableURLRequest = NSMutableURLRequest(url:url as URL)
        
        let bodyData = String(1)
        
        request.httpMethod = "POST"
        request.httpBody = bodyData.data(using: String.Encoding.utf8)
        NSURLConnection.sendAsynchronousRequest(request as URLRequest, queue: OperationQueue.main)
        {
            (response, data, error) in
            print(response!)
            
            if let httpResponse = response as? HTTPURLResponse {
                let statusCode = httpResponse.statusCode
                
                if statusCode==200 {
                    print("Connection Successful")
                    
                } else {
                    print("Connection Failed (!200)")
                }
            }
        }
    }
    
    
}

