//
//  ViewController.m
//  CustomCellApp
//
//  Created by Alexander Valdes on 10/14/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

#import "ViewController.h"
#import "Data.h"
#import "CustomCell.h"
#import "Settings.h"
#import <SDWebImage/UIImageView+WebCache.h>

// Server URL (For Testing)
#define getDataURL @"http://79.170.40.227/gamenotify.org/json.php"

@interface ViewController ()
@end

@implementation ViewController
@synthesize myTableView, mySearchBar, jsonArray, dataArray, filteredArray, isFiltered, followedArray;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Custom Cell
    self.myTableView.dataSource = self;
    self.myTableView.delegate = self;
    
    // Allocating Array
    followedArray = [[NSMutableArray alloc] init];
    
    // Search Bar
    mySearchBar.delegate = self;
    
    // Dismissing Keyboard
    UITapGestureRecognizer *gestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
    [myTableView addGestureRecognizer:gestureRecognizer];
    
    // Load Data
    [self retrieveData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

// Number of Sections
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

// Gets the number of rows by counting the arrays
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if (!isFiltered) {
        
        if (section == 0) {
            return [followedArray count];
        }
        else if (section == 1) {
            return [dataArray count];
        }
    }
    return [filteredArray count];
    
}

// Title for Section Headers
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return @"Followed Data";
    }
    else {
        return @"All Data";
    }
}

// Height of row
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 140;
}

// Setting up the cells in the rows *Main*
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Coloring TableView
    myTableView.backgroundColor = [UIColor whiteColor];
    
    // Configuring the cell
    Data * dataObject;
    if (!isFiltered) {
        
        if (indexPath.section == 0) {
            dataObject = [followedArray objectAtIndex:indexPath.row];
            [cell populateCell:dataObject isFollowed:YES indexPath:indexPath parentView:self];
        }
        else if (indexPath.section == 1) {
            dataObject = [dataArray objectAtIndex:indexPath.row];
            [cell populateCell:dataObject isFollowed:NO indexPath:indexPath parentView:self];
        }
    }
    else {
        dataObject = [filteredArray objectAtIndex:indexPath.row];
        [cell populateCell:dataObject isFollowed:NO indexPath:indexPath parentView:self];
    }
    return cell;
}

#pragma mark -
#pragma mark Class Methods

// Hiding Keyboard
-(void)hideKeyboard {
    [self.view endEditing:NO];
}

// Settings Button (No Action)
-(IBAction)settingsButton:(id)sender {
}

// Search Bar
-(void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    
    if (searchText.length == 0) {
        isFiltered = NO;
    } else {
        isFiltered = YES;
        
        //searching only in dataArray
        
        filteredArray = [[NSArray alloc] init];
        NSPredicate *resultPredicate = [NSPredicate predicateWithFormat:@"self.dataName contains[c] %@", searchText];
        filteredArray = [dataArray filteredArrayUsingPredicate:resultPredicate];
        
    }
    [self.myTableView reloadData];
}

// Search Bar Clicked
-(void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [mySearchBar resignFirstResponder];
}

// Follow Button Clicked
-(void)followButtonClick:(UIButton *)sender {
    
    // Adding row to tag
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.myTableView];
    NSIndexPath *indexPath = [self.myTableView indexPathForRowAtPoint:buttonPosition];
    
    // Creating an action per tag
    if (indexPath != nil)
    {
        //NSLog(@"Current Row = %@", indexPath);
        
        // Showing Status Labels
        CustomCell *cell = [self.myTableView cellForRowAtIndexPath:indexPath];
        cell.firstStatusLabel.hidden = NO;
        cell.secondStatusLabel.hidden = NO;
        
        // Change Follow to Following
        [sender setImage:[UIImage imageNamed:@"follow.png"] forState:UIControlStateNormal];
        cell.followButton.hidden = YES;
        cell.followedButton.hidden = NO;
        
        
        [self.myTableView beginUpdates];
        
        // ----- Inserting Cell to Section 0 -----
        [followedArray insertObject:[dataArray objectAtIndex:indexPath.row] atIndex:0];
        [myTableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:0]] withRowAnimation:UITableViewRowAnimationFade];
        //NSLog(@"indexPath.row = %ld", (long)indexPath.row);
        
        // ----- Removing Cell from Section 1 -----
        [dataArray removeObjectAtIndex:indexPath.row];
        NSInteger rowToRemove = indexPath.row;
        [self.myTableView deleteRowsAtIndexPaths:[NSMutableArray arrayWithObjects:[NSIndexPath indexPathForRow:rowToRemove inSection:1], nil] withRowAnimation:YES];
        //NSLog(@"Array =%@",followedArray);
        
        [self.myTableView endUpdates];
    }
}

// Followed Button Clicked
-(void)followedButtonClick:(UIButton *)sender {
    
    // Adding row to tag
    CGPoint buttonPosition = [sender convertPoint:CGPointZero toView:self.myTableView];
    NSIndexPath *indexPath = [self.myTableView indexPathForRowAtPoint:buttonPosition];
    
    // Creating an action per tag
    if (indexPath != nil)
    {
        //NSLog(@"Current Row = %@", indexPath);
        
        // Hiding Status Labels
        CustomCell *cell = [self.myTableView cellForRowAtIndexPath:indexPath];
        cell.firstStatusLabel.hidden = YES;
        cell.secondStatusLabel.hidden = YES;
        
        // Change Following to Follow
        [sender setImage:[UIImage imageNamed:@"followed.png"] forState:UIControlStateNormal];
        cell.followButton.hidden = NO;
        cell.followedButton.hidden = YES;
        
        
        [self.myTableView beginUpdates];
        
        // ----- Inserting Cell to Section 1 -----
        [dataArray insertObject:[followedArray objectAtIndex:indexPath.row] atIndex:0];
        [myTableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:0 inSection:1]] withRowAnimation:UITableViewRowAnimationFade];
        //NSLog(@"indexPath.row = %ld", (long)indexPath.row);
        
        // ----- Removing Cell from Section 0 -----
        [followedArray removeObjectAtIndex:indexPath.row];
        NSInteger rowToRemove = indexPath.row;
        [self.myTableView deleteRowsAtIndexPaths:[NSMutableArray arrayWithObjects:[NSIndexPath indexPathForRow:rowToRemove inSection:0], nil] withRowAnimation:YES];
        //NSLog(@"Array =%@",followedArray);
        
        [self.myTableView endUpdates];
    }
}

// Connecting to server to get data
-(void)retrieveData {
    NSURL * url = [NSURL URLWithString:getDataURL];
    NSData * data = [NSData dataWithContentsOfURL:url];
    
    jsonArray = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
    
    // Setting up data array
    dataArray = [[NSMutableArray alloc] init];
    
    // Looping through jsonArray
    for (int i = 0; i < jsonArray.count; i++) {
        
        // Create Data Object
        NSString * dID = [[jsonArray objectAtIndex:i] objectForKey:@"id"];
        NSString * dName = [[jsonArray objectAtIndex:i] objectForKey:@"dataName"];
        NSString * dStatus1 = [[jsonArray objectAtIndex:i] objectForKey:@"dataStatus1"];
        NSString * dStatus2 = [[jsonArray objectAtIndex:i] objectForKey:@"dataStatus2"];
        NSString * dURL = [[jsonArray objectAtIndex:i] objectForKey:@"dataURL"];
        
        // Add Data Objects to Data Array
        [dataArray addObject:[[Data alloc] initWithDataName:dName andDataStatus1:dStatus1 andDataStatus2:dStatus2 andDataURL:dURL andDataID:dID]];
    }
    
    [self.myTableView reloadData];
}

@end
