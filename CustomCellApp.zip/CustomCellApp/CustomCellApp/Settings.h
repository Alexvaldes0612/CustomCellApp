//
//  Settings.h
//  CustomCellApp
//
//  Created by Alexander Valdes on 10/17/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Settings : UIViewController

- (IBAction)backButton:(id)sender;

@end
