//
//  CustomCell.m
//  CustomCellApp
//
//  Created by Alexander Valdes on 10/14/16.
//  Copyright © 2016 Dase Inc. All rights reserved.
//

#import "CustomCell.h"
#import "ViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

@implementation CustomCell
@synthesize firstStatusLabel, secondStatusLabel, myImageView, followButton, followedButton;

- (void)awakeFromNib {
    [super awakeFromNib];
    self.followButton.hidden = YES;
    self.followedButton.hidden = YES;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

-(void)populateCell:(Data *)dataObject isFollowed:(BOOL)isFollowed indexPath:(NSIndexPath *)indexPath parentView:(id)parentView{
    
    // Loading Background Color
    self.backgroundColor = [UIColor whiteColor];
    
    // Loading Images
    NSURL * imgURL = [dataObject valueForKey:@"dataURL"];
    [self.myImageView setContentMode:UIViewContentModeScaleAspectFit];
    [self.myImageView sd_setImageWithURL:imgURL placeholderImage:[UIImage imageNamed:@"no-image.png"] options:SDWebImageRefreshCached];
    
    // Loading Status Labels
    self.firstStatusLabel.text = dataObject.dataStatus1;
    self.secondStatusLabel.text = dataObject.dataStatus2;
    self.firstStatusLabel.hidden = YES;
    self.secondStatusLabel.hidden = YES;
    
    if (isFollowed){
        self.followedButton.tag = indexPath.row;
        [self.followedButton addTarget:parentView action:@selector(followedButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        self.followedButton.hidden = NO;
        self.followButton.hidden = YES;
        // Status Lables
        self.firstStatusLabel.hidden = NO;
        self.secondStatusLabel.hidden = NO;
        
    }else{
        self.followButton.tag = indexPath.row;
        [self.followButton addTarget:parentView action:@selector(followButtonClick:) forControlEvents:UIControlEventTouchUpInside];
        self.followedButton.hidden = YES;
        self.followButton.hidden = NO;
        // Status Labels
        self.firstStatusLabel.hidden = YES;
        self.secondStatusLabel.hidden = YES;
    }
}

@end
